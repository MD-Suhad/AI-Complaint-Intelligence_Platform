# AI Complaint Intelligence Platform — Phase 1

Basic CRUD + rule-based classification. Foundation for later phases (Kafka, Elasticsearch,
Redis, CQRS, SLA engine).

## Stack
- Java 25
- Spring Boot 3.4.2
- PostgreSQL 16
- Maven
- Testcontainers (integration tests against a real PostgreSQL instance)

## Setup

### 1. Start PostgreSQL
```bash
docker compose up -d
```
This starts Postgres on `localhost:5432` with database `complaint_platform`.

### 2. Open in IntelliJ
Open the project folder as a Maven project. IntelliJ will auto-import dependencies from `pom.xml`.
Make sure Project SDK is set to Java 25 (File → Project Structure → Project SDK).

### 3. Run
Run `ComplaintPlatformApplication.java` directly from IntelliJ, or:
```bash
mvn spring-boot:run
```
App starts on `http://localhost:8080`.

## API Endpoints

| Method | Endpoint                          | Description              |
|--------|------------------------------------|---------------------------|
| POST   | `/api/v1/complaints`               | Create a complaint        |
| GET    | `/api/v1/complaints/{id}`          | Get a complaint by id     |
| GET    | `/api/v1/complaints`               | List complaints (paged)   |
| PATCH  | `/api/v1/complaints/{id}/status`   | Update complaint status   |

### Example: Create a complaint
```bash
curl -X POST http://localhost:8080/api/v1/complaints \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Internet not working since 3 days",
    "description": "My broadband connection has been down for three days, no technician visited.",
    "complainantId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
  }'
```

### Example: Update status
```bash
curl -X PATCH http://localhost:8080/api/v1/complaints/{id}/status \
  -H "Content-Type: application/json" \
  -d '{
    "newStatus": "IN_PROGRESS",
    "note": "Assigned to technician"
  }'
```

## Running Tests
```bash
mvn test
```
Integration tests spin up a real PostgreSQL container automatically via Testcontainers —
requires Docker to be running locally.

## What's Implemented (Phase 1)
- Complaint CRUD (create, get by id, list with pagination, status update)
- Rule-based classification (category + severity) — placeholder for future AI/NLP service
- Idempotency key support to prevent duplicate submission on client retry
- Status transition state machine (prevents illegal jumps like CLOSED → OPEN)
- Audit trail (`ComplaintStatusHistory`) for every status change
- Global exception handling with consistent error response shape
- Integration test against real Postgres via Testcontainers

## What's Next
- **Phase 2**: Kafka-based async ingestion, decouple classification into its own consumer
- **Phase 3**: Elasticsearch for full-text + semantic dedup search
- **Phase 4**: Redis caching, rate limiting, SLA engine (delayed jobs via sorted sets)
- **Phase 5**: CQRS read model for analytics dashboard, load testing with k6/JMeter
