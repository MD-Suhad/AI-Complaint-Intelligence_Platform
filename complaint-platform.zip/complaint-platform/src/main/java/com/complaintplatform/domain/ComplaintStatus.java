package com.complaintplatform.domain;

public enum ComplaintStatus {
    OPEN,
    IN_PROGRESS,
    ESCALATED,
    RESOLVED,
    CLOSED,
    REJECTED
}
