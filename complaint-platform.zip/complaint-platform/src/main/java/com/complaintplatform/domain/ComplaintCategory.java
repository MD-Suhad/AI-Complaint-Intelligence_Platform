package com.complaintplatform.domain;

public enum ComplaintCategory {
    ECOMMERCE,
    ISP_TELECOM,
    BANKING_FINANCE,
    UTILITY,
    GOVERNMENT_SERVICE,
    HEALTHCARE,
    TRANSPORT,
    OTHER,
    UNCLASSIFIED   // default before classification service runs
}
