package com.complaintplatform.domain;

public enum Severity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
