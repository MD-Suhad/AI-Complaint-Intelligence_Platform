package com.complaintplatform.controller;

import com.complaintplatform.domain.Complaint;
import com.complaintplatform.dto.ComplaintResponse;
import com.complaintplatform.dto.CreateComplaintRequest;
import com.complaintplatform.dto.UpdateStatusRequest;
import com.complaintplatform.service.ComplaintService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping
    public ResponseEntity<ComplaintResponse> create(@Valid @RequestBody CreateComplaintRequest request) {
        Complaint created = complaintService.createComplaint(request);
        return ResponseEntity
                .created(URI.create("/api/v1/complaints/" + created.getId()))
                .body(ComplaintResponse.from(created));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplaintResponse> getById(@PathVariable UUID id) {
        Complaint complaint = complaintService.getById(id);
        return ResponseEntity.ok(ComplaintResponse.from(complaint));
    }

    @GetMapping
    public ResponseEntity<Page<ComplaintResponse>> getAll(Pageable pageable) {
        Page<ComplaintResponse> page = complaintService.getAll(pageable)
                .map(ComplaintResponse::from);
        return ResponseEntity.ok(page);
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ComplaintResponse> updateStatus(
            @PathVariable UUID id,
            @Valid @RequestBody UpdateStatusRequest request) {
        Complaint updated = complaintService.updateStatus(id, request);
        return ResponseEntity.ok(ComplaintResponse.from(updated));
    }
}
