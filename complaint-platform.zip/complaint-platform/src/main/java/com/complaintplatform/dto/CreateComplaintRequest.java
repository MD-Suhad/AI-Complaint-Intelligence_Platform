package com.complaintplatform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.UUID;

public record CreateComplaintRequest(

        @NotBlank(message = "Title is required")
        @Size(max = 200, message = "Title must not exceed 200 characters")
        String title,

        @NotBlank(message = "Description is required")
        @Size(min = 10, message = "Description must be at least 10 characters")
        String description,

        @NotNull(message = "Complainant id is required")
        UUID complainantId,

        // Optional: client can pass its own idempotency key (e.g. UUID generated on submit button click)
        // If not passed, the service generates one internally.
        String idempotencyKey
) {}
