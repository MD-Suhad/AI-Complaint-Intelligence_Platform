package com.complaintplatform.dto;

import com.complaintplatform.domain.Complaint;
import com.complaintplatform.domain.ComplaintCategory;
import com.complaintplatform.domain.ComplaintStatus;
import com.complaintplatform.domain.Severity;

import java.time.Instant;
import java.util.UUID;

public record ComplaintResponse(
        UUID id,
        String title,
        String description,
        ComplaintCategory category,
        Severity severity,
        ComplaintStatus status,
        UUID complainantId,
        Instant createdAt,
        Instant updatedAt
) {
    public static ComplaintResponse from(Complaint complaint) {
        return new ComplaintResponse(
                complaint.getId(),
                complaint.getTitle(),
                complaint.getDescription(),
                complaint.getCategory(),
                complaint.getSeverity(),
                complaint.getStatus(),
                complaint.getComplainantId(),
                complaint.getCreatedAt(),
                complaint.getUpdatedAt()
        );
    }
}
