package com.complaintplatform.dto;

import com.complaintplatform.domain.ComplaintStatus;
import jakarta.validation.constraints.NotNull;

public record UpdateStatusRequest(

        @NotNull(message = "New status is required")
        ComplaintStatus newStatus,

        String note
) {}
