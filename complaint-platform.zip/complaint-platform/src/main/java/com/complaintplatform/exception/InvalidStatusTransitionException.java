package com.complaintplatform.exception;

import com.complaintplatform.domain.ComplaintStatus;

public class InvalidStatusTransitionException extends RuntimeException {

    public InvalidStatusTransitionException(ComplaintStatus from, ComplaintStatus to) {
        super("Cannot transition complaint status from " + from + " to " + to);
    }
}
