package com.complaintplatform.service;

import com.complaintplatform.domain.ComplaintCategory;
import com.complaintplatform.domain.Severity;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Map;

/**
 * Phase 1: simple keyword-matching classifier.
 * Phase 3+: replace this with a call to an NLP/LLM-based classification microservice
 * (e.g. via Kafka event -> classification consumer -> embeddings/LLM call).
 * Keeping this behind an interface-like single responsibility class makes that swap easy later.
 */
@Service
public class ComplaintClassificationService {

    private static final Map<ComplaintCategory, String[]> CATEGORY_KEYWORDS = Map.of(
            ComplaintCategory.ECOMMERCE, new String[]{"order", "delivery", "refund", "product", "seller", "return"},
            ComplaintCategory.ISP_TELECOM, new String[]{"internet", "wifi", "network", "sim", "broadband", "signal"},
            ComplaintCategory.BANKING_FINANCE, new String[]{"bank", "account", "transaction", "atm", "card", "loan"},
            ComplaintCategory.UTILITY, new String[]{"electricity", "gas", "water", "power", "outage", "bill"},
            ComplaintCategory.GOVERNMENT_SERVICE, new String[]{"office", "government", "passport", "certificate", "license"},
            ComplaintCategory.HEALTHCARE, new String[]{"hospital", "doctor", "medicine", "treatment", "clinic"},
            ComplaintCategory.TRANSPORT, new String[]{"bus", "train", "ride", "driver", "fare", "flight"}
    );

    private static final String[] CRITICAL_KEYWORDS = {"fraud", "scam", "life threatening", "urgent", "emergency", "stolen"};
    private static final String[] HIGH_KEYWORDS = {"not working", "failed", "money deducted", "no response", "harassment"};

    public ComplaintCategory classifyCategory(String title, String description) {
        String text = (title + " " + description).toLowerCase(Locale.ROOT);

        for (Map.Entry<ComplaintCategory, String[]> entry : CATEGORY_KEYWORDS.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (text.contains(keyword)) {
                    return entry.getKey();
                }
            }
        }
        return ComplaintCategory.OTHER;
    }

    public Severity assessSeverity(String title, String description) {
        String text = (title + " " + description).toLowerCase(Locale.ROOT);

        for (String keyword : CRITICAL_KEYWORDS) {
            if (text.contains(keyword)) {
                return Severity.CRITICAL;
            }
        }
        for (String keyword : HIGH_KEYWORDS) {
            if (text.contains(keyword)) {
                return Severity.HIGH;
            }
        }
        return Severity.MEDIUM;
    }
}
