package com.complaintplatform.service;

import com.complaintplatform.domain.Complaint;
import com.complaintplatform.domain.ComplaintStatus;
import com.complaintplatform.domain.ComplaintStatusHistory;
import com.complaintplatform.dto.CreateComplaintRequest;
import com.complaintplatform.dto.UpdateStatusRequest;
import com.complaintplatform.exception.ComplaintNotFoundException;
import com.complaintplatform.repository.ComplaintRepository;
import com.complaintplatform.repository.ComplaintStatusHistoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final ComplaintStatusHistoryRepository historyRepository;
    private final ComplaintClassificationService classificationService;
    private final ComplaintStatusTransitionValidator transitionValidator;

    public Complaint createComplaint(CreateComplaintRequest request) {
        // Idempotency check: if this key was already used, return the existing record
        // instead of creating a duplicate. Protects against double-submit on network retry.
        String idempotencyKey = request.idempotencyKey() != null
                ? request.idempotencyKey()
                : UUID.randomUUID().toString();

        var existing = complaintRepository.findByIdempotencyKey(idempotencyKey);
        if (existing.isPresent()) {
            return existing.get();
        }

        var category = classificationService.classifyCategory(request.title(), request.description());
        var severity = classificationService.assessSeverity(request.title(), request.description());

        Complaint complaint = Complaint.builder()
                .title(request.title())
                .description(request.description())
                .complainantId(request.complainantId())
                .category(category)
                .severity(severity)
                .status(ComplaintStatus.OPEN)
                .idempotencyKey(idempotencyKey)
                .build();

        return complaintRepository.save(complaint);
    }

    @Transactional(readOnly = true)
    public Complaint getById(UUID id) {
        return complaintRepository.findById(id)
                .orElseThrow(() -> new ComplaintNotFoundException(id));
    }

    @Transactional(readOnly = true)
    public Page<Complaint> getAll(Pageable pageable) {
        return complaintRepository.findAll(pageable);
    }

    public Complaint updateStatus(UUID id, UpdateStatusRequest request) {
        Complaint complaint = getById(id);
        ComplaintStatus currentStatus = complaint.getStatus();
        ComplaintStatus newStatus = request.newStatus();

        transitionValidator.validate(currentStatus, newStatus);

        complaint.setStatus(newStatus);
        Complaint updated = complaintRepository.save(complaint);

        // audit trail entry
        ComplaintStatusHistory history = ComplaintStatusHistory.builder()
                .complaintId(id)
                .previousStatus(currentStatus)
                .newStatus(newStatus)
                .note(request.note())
                .build();
        historyRepository.save(history);

        return updated;
    }
}
