package com.complaintplatform.service;

import com.complaintplatform.domain.ComplaintStatus;
import com.complaintplatform.exception.InvalidStatusTransitionException;
import org.springframework.stereotype.Component;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * Encodes the complaint status state machine.
 * Prevents illegal jumps (e.g. CLOSED -> OPEN) at the service layer,
 * instead of relying on ad-hoc if/else checks scattered around the codebase.
 */
@Component
public class ComplaintStatusTransitionValidator {

    private static final Map<ComplaintStatus, Set<ComplaintStatus>> ALLOWED_TRANSITIONS = new EnumMap<>(ComplaintStatus.class);

    static {
        ALLOWED_TRANSITIONS.put(ComplaintStatus.OPEN, EnumSet.of(
                ComplaintStatus.IN_PROGRESS, ComplaintStatus.REJECTED, ComplaintStatus.ESCALATED));
        ALLOWED_TRANSITIONS.put(ComplaintStatus.IN_PROGRESS, EnumSet.of(
                ComplaintStatus.RESOLVED, ComplaintStatus.ESCALATED, ComplaintStatus.REJECTED));
        ALLOWED_TRANSITIONS.put(ComplaintStatus.ESCALATED, EnumSet.of(
                ComplaintStatus.IN_PROGRESS, ComplaintStatus.RESOLVED));
        ALLOWED_TRANSITIONS.put(ComplaintStatus.RESOLVED, EnumSet.of(
                ComplaintStatus.CLOSED, ComplaintStatus.IN_PROGRESS)); // reopened if unsatisfied
        ALLOWED_TRANSITIONS.put(ComplaintStatus.CLOSED, EnumSet.noneOf(ComplaintStatus.class));
        ALLOWED_TRANSITIONS.put(ComplaintStatus.REJECTED, EnumSet.noneOf(ComplaintStatus.class));
    }

    public void validate(ComplaintStatus current, ComplaintStatus target) {
        Set<ComplaintStatus> allowed = ALLOWED_TRANSITIONS.getOrDefault(current, Set.of());
        if (!allowed.contains(target)) {
            throw new InvalidStatusTransitionException(current, target);
        }
    }
}
