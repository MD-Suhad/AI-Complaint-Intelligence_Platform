package com.complaintplatform.repository;

import com.complaintplatform.domain.Complaint;
import com.complaintplatform.domain.ComplaintCategory;
import com.complaintplatform.domain.ComplaintStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface ComplaintRepository extends JpaRepository<Complaint, UUID> {

    // Used to enforce idempotency: if a request with the same key
    // already exists, return the existing complaint instead of creating a duplicate.
    Optional<Complaint> findByIdempotencyKey(String idempotencyKey);

    Page<Complaint> findByStatus(ComplaintStatus status, Pageable pageable);

    Page<Complaint> findByCategory(ComplaintCategory category, Pageable pageable);

    Page<Complaint> findByComplainantId(UUID complainantId, Pageable pageable);
}
