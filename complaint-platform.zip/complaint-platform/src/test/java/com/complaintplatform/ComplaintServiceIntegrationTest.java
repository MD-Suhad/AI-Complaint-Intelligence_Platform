package com.complaintplatform;

import com.complaintplatform.domain.Complaint;
import com.complaintplatform.dto.CreateComplaintRequest;
import com.complaintplatform.service.ComplaintService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration test against a REAL PostgreSQL instance (via Testcontainers),
 * not a mock. Verifies the full path: controller-less service -> repository -> DB.
 * This is the kind of test that shows real backend engineering rigor.
 */
@SpringBootTest
@Testcontainers
class ComplaintServiceIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16")
            .withDatabaseName("complaint_platform_test")
            .withUsername("test")
            .withPassword("test");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private ComplaintService complaintService;

    @Test
    void shouldCreateComplaintAndPersistToDatabase() {
        var request = new CreateComplaintRequest(
                "Internet not working since 3 days",
                "My broadband connection has been down for three days, no technician has visited yet.",
                UUID.randomUUID(),
                null
        );

        Complaint created = complaintService.createComplaint(request);

        assertThat(created.getId()).isNotNull();
        assertThat(created.getCategory()).isNotNull();
        assertThat(created.getSeverity()).isNotNull();

        Complaint fetched = complaintService.getById(created.getId());
        assertThat(fetched.getTitle()).isEqualTo(request.title());
    }

    @Test
    void shouldReturnSameComplaintForDuplicateIdempotencyKey() {
        String key = "test-idempotency-key-123";
        var request = new CreateComplaintRequest(
                "Duplicate submit test",
                "Testing that resubmitting with the same idempotency key does not create duplicates.",
                UUID.randomUUID(),
                key
        );

        Complaint first = complaintService.createComplaint(request);
        Complaint second = complaintService.createComplaint(request);

        assertThat(first.getId()).isEqualTo(second.getId());
    }
}
